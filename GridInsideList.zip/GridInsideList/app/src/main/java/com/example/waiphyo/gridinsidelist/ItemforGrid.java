package com.example.waiphyo.gridinsidelist;

public class ItemforGrid {
    ItemforGrid(String titles,int images)
    {
        this.titles = titles;
        this.images = images;
    }
    public String getTitles() {
        return titles;
    }

    public int getImages() {
        return images;
    }

    String titles;
    int images;
}
