package com.example.waiphyo.gridinsidelist;

import java.util.ArrayList;

public class ItemforList {
    private String  section;
    private ArrayList<ItemforGrid> arrayList;

    ItemforList(String section,ArrayList<ItemforGrid> arrayList)
    {
        this.section = section;
        this.arrayList = arrayList;
    }


    public String getSection() {
        return section;
    }

    public ArrayList<ItemforGrid> getArrayList() {
        return arrayList;
    }


}
