package com.example.waiphyo.gridinsidelist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ArrayList<ItemforList> list;
    private ArrayList<ItemforGrid> grid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recycler);
        list = new ArrayList<>();
        grid = new ArrayList<>();
        addItems();

        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        AdapterList adapterList = new AdapterList(list,MainActivity.this);
        recyclerView.setAdapter(adapterList);


    }

    void addItems(){
        addgrid();
        for(int lst =0;lst<5;lst++)

        list.add(new ItemforList("section",grid));
    }
    void addgrid()
    {
        for(int grd=0;grd<4;grd++)
        {
            grid.add(new ItemforGrid("image"+(grd+1),R.mipmap.ic_launcher));
        }
    }



}
