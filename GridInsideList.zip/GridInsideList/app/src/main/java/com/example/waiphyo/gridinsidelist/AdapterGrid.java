package com.example.waiphyo.gridinsidelist;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AdapterGrid extends RecyclerView.Adapter<AdapterGrid.MyHoldergrid> {
    ArrayList<ItemforGrid> arrayListgrid;
    AdapterGrid(ArrayList<ItemforGrid> arraylistgrid)
    {
        this.arrayListgrid = arraylistgrid;
    }


    @NonNull
    @Override
    public MyHoldergrid onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item,viewGroup,false);

        return new MyHoldergrid(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHoldergrid myHoldergrid, int i) {
        myHoldergrid.textView.setText(arrayListgrid.get(i).getTitles());
        myHoldergrid.imageView.setImageResource(arrayListgrid.get(i).getImages());

    }

    @Override
    public int getItemCount() {
        return arrayListgrid.size();
    }

    public class MyHoldergrid extends RecyclerView.ViewHolder{
        private TextView textView;
        private ImageView imageView;
        public MyHoldergrid(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textview);
            imageView = itemView.findViewById(R.id.imageview);
        }
    }


}
